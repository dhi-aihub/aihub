#!/bin/bash
python3 trainer.py
